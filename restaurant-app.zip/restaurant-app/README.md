# Restaurant App (Angular) - Minimal scaffold

هذه حزمة مشروع Angular بسيطة جاهزة للنسخ والبدء. لتنصيب المشروع وتشغيله:
1. تأكد أن لديك Node.js و npm مثبتين.
2. فك الضغط أو انسخ المجلد وأدخل: `cd restaurant-app`
3. شغل: `npm install`
4. ثم: `npm start` أو `npx ng serve --open`

ملاحظة: هذا مشروع هيكلي مصغر — قد تحتاج لتثبيت Angular CLI عالمياً إذا رغبت (`npm i -g @angular/cli`).
