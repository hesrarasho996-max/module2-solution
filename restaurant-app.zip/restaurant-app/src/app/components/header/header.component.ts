import { Component } from '@angular/core';

@Component({
  selector: 'app-header',
  template: `
    <nav>
      <a routerLink="/">القائمة</a> |
      <a routerLink="/cart">سلة التسوق</a>
    </nav>
    <hr>
  `
})
export class HeaderComponent {}
