import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MenuService } from '../../services/menu.service';

@Component({
  selector: 'app-menu',
  template: `
  <h2>قائمة الطعام</h2>
  <div *ngFor="let category of categories">
    <h3>{{ category.name }}</h3>
    <div *ngFor="let item of category.items" class="menu-item" (click)="viewDetails(item.id)">
      <h4>{{ item.name }}</h4>
      <p>السعر: {{ item.price }} ريال</p>
    </div>
  </div>
  `
})
export class MenuComponent implements OnInit {
  categories: any[] = [];
  constructor(private menuService: MenuService, private router: Router) {}
  ngOnInit() {
    this.categories = this.menuService.getCategories();
  }
  viewDetails(id: number) {
    this.router.navigate(['/item', id]);
  }
}
