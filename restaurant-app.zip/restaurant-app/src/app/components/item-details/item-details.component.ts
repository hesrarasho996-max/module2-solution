import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { MenuService } from '../../services/menu.service';
import { CartService } from '../../services/cart.service';

@Component({
  selector: 'app-item-details',
  template: `
  <div *ngIf="item; else notFound">
    <h2>{{ item.name }}</h2>
    <img *ngIf="item.image" [src]="item.image" alt="{{ item.name }}" width="200">
    <p>{{ item.description }}</p>
    <p>السعر: {{ item.price }} ريال</p>
    <button (click)="addToCart(item)">إضافة إلى السلة</button>
    <button (click)="back()">رجوع</button>
  </div>
  <ng-template #notFound>
    <p>الصنف غير موجود</p>
  </ng-template>
  `
})
export class ItemDetailsComponent implements OnInit {
  item: any;
  constructor(
    private route: ActivatedRoute,
    private menuService: MenuService,
    private cartService: CartService,
    private router: Router
  ) {}
  ngOnInit() {
    const id = Number(this.route.snapshot.paramMap.get('id'));
    this.item = this.menuService.getItemById(id);
  }
  addToCart(item: any) {
    this.cartService.addItem(item);
    this.router.navigate(['/cart']);
  }
  back() {
    this.router.navigate(['/']);
  }
}
