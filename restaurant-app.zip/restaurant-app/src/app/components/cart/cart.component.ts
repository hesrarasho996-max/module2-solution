import { Component, OnInit } from '@angular/core';
import { CartService } from '../../services/cart.service';

@Component({
  selector: 'app-cart',
  template: `
  <h2>سلة التسوق</h2>
  <div *ngIf="cartItems.length > 0; else empty">
    <div *ngFor="let item of cartItems; let i = index">
      <p>{{ item.name }} - {{ item.price }} ريال</p>
      <button (click)="remove(item)">إزالة</button>
    </div>
    <h3>المجموع الكلي: {{ total() }} ريال</h3>
  </div>
  <ng-template #empty>
    <p>السلة فارغة</p>
  </ng-template>
  `
})
export class CartComponent implements OnInit {
  cartItems: any[] = [];
  constructor(private cartService: CartService) {}
  ngOnInit() {
    this.cartItems = this.cartService.getItems();
  }
  remove(item: any) {
    this.cartService.removeItem(item);
    this.cartItems = this.cartService.getItems();
  }
  total() {
    return this.cartService.getTotal();
  }
}
