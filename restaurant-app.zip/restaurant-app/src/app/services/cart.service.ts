import { Injectable } from '@angular/core';

@Injectable({ providedIn: 'root' })
export class CartService {
  private cart: any[] = [];

  addItem(item: any) {
    this.cart.push(item);
  }

  removeItem(item: any) {
    this.cart = this.cart.filter(i => i.id !== item.id);
  }

  getItems() {
    return this.cart;
  }

  getTotal() {
    return this.cart.reduce((s, i) => s + i.price, 0);
  }
}
