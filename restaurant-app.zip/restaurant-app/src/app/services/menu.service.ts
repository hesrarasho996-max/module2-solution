import { Injectable } from '@angular/core';

@Injectable({ providedIn: 'root' })
export class MenuService {
  private items = [
    { id: 1, name: 'برجر', price: 25, description: 'برجر لحم لذيذ', category: 'وجبات رئيسية', image: '' },
    { id: 2, name: 'بيتزا', price: 30, description: 'بيتزا جبن شهية', category: 'وجبات رئيسية', image: '' },
    { id: 3, name: 'عصير برتقال', price: 10, description: 'عصير طبيعي', category: 'مشروبات', image: '' }
  ];

  getAllItems() {
    return this.items;
  }

  getItemById(id: number) {
    return this.items.find(i => i.id === id);
  }

  getCategories() {
    const cats = Array.from(new Set(this.items.map(i => i.category)));
    return cats.map(name => ({ name, items: this.items.filter(i => i.category === name) }));
  }
}
